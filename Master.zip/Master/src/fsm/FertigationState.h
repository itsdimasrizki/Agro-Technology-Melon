#ifndef FERTIGATION_STATE_H
#define FERTIGATION_STATE_H

enum class FertigationState {
    IDLE,

    WAIT_DAILY_MIX,

    PREPARE_DAILY_MIX,

    FILL_WATER,

    PRE_MIX_A,

    ADD_NUTRIENT_A,

    MIX_A,

    PRE_MIX_B,

    ADD_NUTRIENT_B,

    MIX_B,

    VALIDATE,

    PRE_MIX_CORRECTION,

    CORRECT_PPM,

    CORRECTION_MIX,

    READY,

    PRE_IRRIGATION_MIX,

    PRE_IRRIGATION_VALIDATE,

    IRRIGATION,

    ERROR
};

#endif