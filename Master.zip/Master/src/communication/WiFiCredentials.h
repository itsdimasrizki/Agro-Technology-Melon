#ifndef WIFI_CREDENTIALS_H
#define WIFI_CREDENTIALS_H

#define WIFI_SSID     "SSID"
#define WIFI_PASSWORD "PASSWORD"

#endif
